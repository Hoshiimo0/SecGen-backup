HOW TO BUILD FOR WINDOWS
========================
Actually, if you want to build r2 for windows, you can use native compiler with mingw32 or
cygwin, but there's also the possibility to crosscompile from a Linux box:


Crosscompilation
----------------

**ArchLinux**

	./configure --with-compiler=i486-mingw32-gcc --with-ostype=windows --host=i486-unknown-windows
	make
	make w32dist

	cd swig
	export CC=i486-mingw32-gcc
	export CXX=i486-mingw32-g++
	unset CFLAGS
	unset LDFLAGS
	export LDFLAGS="-L${HOME}/.wine/drive_c/Python27/libs ${LDFLAGS}"
	export CFLAGS="-Wl,--enable-auto-import -L../../radare2-w32-0.5 ${CFLAGS}"
	./configure --with-ostype=windows --host=i486-unknown-windows --with-cc=i486-mingw32-gcc --with-cxx=i486-mingw32-g++

  
**Ubuntu**
 
	sudo apt-get install mingw32
	./configure --with-compiler=i586-mingw32msvc-gcc  --with-ostype=windows --host=i586-unknown-windows
	make
	make w32dist

**Windows x86-64**
 
***Setup toolchain***
    
	open http://mingw-w64.sourceforge.net/
	wget http://switch.dl.sourceforge.net/project/mingw-w64/Toolchains%20targetting%20Win64/Automated%20Builds/mingw-w64-bin_i686-linux_20110627.tar.bz2
	mkdir -p mingw64
	tar xjvf mingw-w64*.bz2 -C mingw64
	export PATH=$PWD/mingw64/bin:$PATH
  
Build radare2
-------------
  
	./configure --with-compiler=x86_64-w64-mingw32-gcc --with-ostype=windows --host=x86_64-unknown-windows


Python bindings:
----------------

	wget http://www.python.org/ftp/python/2.7/python-2.7.msi
	msiexec /i python-2.7.msi
	cd r2-bindings
	make w32
	make w32dist
